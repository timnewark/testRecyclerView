package com.example.testrecyclerview;

public interface RecyclerViewInterface{
    //interface is a contract between any class that imprelements it and makes sure that class has methods etc. this will change the clickjs
    void onItemClick (int position);
}
