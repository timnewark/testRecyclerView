package com.example.testrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface{

    ArrayList<bridgeModel> bridgeModelsArrayList = new ArrayList<>();

    int[] bridgeImages = {      //need to be in correct order
            R.drawable.ic_baseline_18mp_24, R.drawable.ic_baseline_23mp_24,
            R.drawable.ic_baseline_18mp_24, R.drawable.ic_baseline_bike_scooter_24,
            R.drawable.ic_baseline_explore_24, R.drawable.ic_baseline_gps_not_fixed_24,
            R.drawable.ic_baseline_video_settings_24, R.drawable.ic_baseline_volume_mute_24,
            R.drawable.ic_baseline_wb_sunny_24, R.drawable.ic_launcher_background,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.myRecyclerViewID);

        setUpBridgeModelsMethod();

        recyclerViewAdapter adapter = new recyclerViewAdapter(this, bridgeModelsArrayList, this);


        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    private void setUpBridgeModelsMethod(){
    String[] bridgeNamesFull = getResources().getStringArray(R.array.bridge_parts_full_txt);
    String[] bridgeNamesAbbv = getResources().getStringArray(R.array.bridge_parts_three_letter_txt);
    String[] bridgeNamesAbbvSmall = getResources().getStringArray(R.array.bridge_parts_one_letter_txt);

    for( int i=0; i<bridgeNamesFull.length;i++){
        bridgeModelsArrayList.add(new bridgeModel(bridgeNamesFull[i],
                bridgeNamesAbbv[i],
                bridgeNamesAbbvSmall[i],
                bridgeImages[i]));


    }
    }


    @Override
    public void onItemClick(int position) { //all information to exe when button is clicked to be put in here!!!

    }
}